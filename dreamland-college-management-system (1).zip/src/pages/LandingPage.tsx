import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { GraduationCap, MapPin, BookOpen, Phone, Globe, Menu, X } from 'lucide-react';

export default function LandingPage() {
  const { t, i18n } = useTranslation();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const toggleLanguage = () => {
    i18n.changeLanguage(i18n.language === 'en' ? 'am' : 'en');
  };

  return (
    <div className="min-h-screen bg-stone-50 font-sans text-stone-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center text-white">
                <GraduationCap size={24} />
              </div>
              <span className="text-xl font-bold tracking-tight text-emerald-800">DREAMLAND</span>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#programs" className="text-sm font-medium hover:text-emerald-600 transition-colors">{t('programs')}</a>
              <a href="#branches" className="text-sm font-medium hover:text-emerald-600 transition-colors">{t('branches')}</a>
              <button 
                onClick={toggleLanguage}
                className="flex items-center gap-1 text-sm font-medium text-stone-600 hover:text-emerald-600"
              >
                <Globe size={16} />
                {i18n.language === 'en' ? 'አማርኛ' : 'English'}
              </button>
              <Link to="/login" className="px-4 py-2 bg-emerald-600 text-white rounded-full text-sm font-semibold hover:bg-emerald-700 transition-all shadow-md">
                {t('login')}
              </Link>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2">
                {isMenuOpen ? <X /> : <Menu />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-5xl md:text-6xl font-extrabold text-stone-900 leading-tight mb-6">
                Empowering <span className="text-emerald-600">Ethiopia's</span> Future Leaders
              </h1>
              <p className="text-lg text-stone-600 mb-8 max-w-lg">
                Dreamland College offers world-class education with multiple branches across Ethiopia. Join us to shape your career and contribute to our nation's growth.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/public-registration" className="px-8 py-4 bg-emerald-600 text-white rounded-2xl font-bold text-lg hover:bg-emerald-700 transition-all shadow-lg hover:shadow-emerald-200 text-center">
                  {t('apply_now')}
                </Link>
                <button className="px-8 py-4 bg-white border-2 border-stone-200 text-stone-700 rounded-2xl font-bold text-lg hover:border-emerald-600 hover:text-emerald-600 transition-all">
                  Learn More
                </button>
              </div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl">
                <img 
                  src="https://picsum.photos/seed/college/800/800" 
                  alt="Students" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl border border-stone-100 hidden sm:block">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center text-stone-900 font-bold">
                    10+
                  </div>
                  <div>
                    <p className="font-bold text-stone-900">Accredited Programs</p>
                    <p className="text-sm text-stone-500">HEIMS Compliant</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* Background Accents */}
        <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-emerald-50 rounded-full blur-3xl -z-10 opacity-50 translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-yellow-50 rounded-full blur-3xl -z-10 opacity-50 -translate-x-1/2 translate-y-1/2" />
      </section>

      {/* Features */}
      <section id="programs" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-stone-900 mb-4">{t('programs')}</h2>
            <div className="w-20 h-1.5 bg-emerald-600 mx-auto rounded-full" />
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: 'Computer Science', icon: <BookOpen className="text-emerald-600" />, desc: 'Master software development, AI, and networking.' },
              { title: 'Accounting & Finance', icon: <BookOpen className="text-emerald-600" />, desc: 'Professional training for the modern financial sector.' },
              { title: 'Management', icon: <BookOpen className="text-emerald-600" />, desc: 'Develop leadership skills for Ethiopian enterprises.' }
            ].map((feature, i) => (
              <div key={i} className="p-8 bg-stone-50 rounded-3xl border border-stone-100 hover:border-emerald-200 transition-all hover:shadow-lg group">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm mb-6 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-stone-900 mb-3">{feature.title}</h3>
                <p className="text-stone-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Branches */}
      <section id="branches" className="py-20 bg-stone-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-bold text-stone-900 mb-6">Our Branches</h2>
              <p className="text-stone-600 mb-8">We are strategically located to serve students across the country with state-of-the-art facilities.</p>
              <div className="space-y-6">
                {[
                  { name: 'Addis Ababa Main', location: '4 Kilo, Addis Ababa' },
                  { name: 'Adama Branch', location: 'City Center, Adama' },
                  { name: 'Hawassa Branch', location: 'Coming Soon' }
                ].map((branch, i) => (
                  <div key={i} className="flex items-start gap-4 p-4 bg-white rounded-2xl shadow-sm border border-stone-100">
                    <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-stone-900">{branch.name}</h4>
                      <p className="text-sm text-stone-500">{branch.location}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-3xl overflow-hidden shadow-xl aspect-video bg-stone-200">
               <img 
                  src="https://picsum.photos/seed/campus/800/600" 
                  alt="Campus" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-stone-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <GraduationCap size={32} className="text-emerald-400" />
                <span className="text-2xl font-bold tracking-tight">DREAMLAND COLLEGE</span>
              </div>
              <p className="text-stone-400 max-w-sm mb-6">
                Providing excellence in education since 2010. Accredited by the Ministry of Education.
              </p>
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-stone-800 flex items-center justify-center hover:bg-emerald-600 transition-colors cursor-pointer">
                  <Phone size={18} />
                </div>
                <div className="w-10 h-10 rounded-full bg-stone-800 flex items-center justify-center hover:bg-emerald-600 transition-colors cursor-pointer">
                  <Globe size={18} />
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-bold mb-6">Quick Links</h4>
              <ul className="space-y-4 text-stone-400">
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Admissions</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Student Portal</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">Staff Portal</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition-colors">News</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6">Contact</h4>
              <ul className="space-y-4 text-stone-400">
                <li className="flex items-center gap-2"><MapPin size={16} /> Addis Ababa, Ethiopia</li>
                <li className="flex items-center gap-2"><Phone size={16} /> +251 11 122 3344</li>
                <li className="flex items-center gap-2"><Globe size={16} /> info@dreamland.edu.et</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-stone-800 mt-12 pt-8 text-center text-stone-500 text-sm">
            © {new Date().getFullYear()} Dreamland College. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
