import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from 'react-i18next';
import { 
  Users, 
  Building2, 
  BookOpen, 
  CreditCard, 
  Bell, 
  LogOut, 
  LayoutDashboard,
  User,
  Search,
  Plus,
  Filter,
  MoreVertical,
  ChevronRight,
  Phone,
  MapPin,
  Settings,
  ShieldCheck
} from 'lucide-react';
import axios from 'axios';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import EditStudentModal from '../components/EditStudentModal';

export default function Dashboard() {
  const { user, logout, token } = useAuth();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [students, setStudents] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [calendars, setCalendars] = useState<any[]>([]);
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [availableCourses, setAvailableCourses] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [integrations, setIntegrations] = useState<any>(null);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const fetchData = async () => {
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const requests = [];

      // Only fetch students if authorized
      if (['superadmin', 'branch_admin', 'faculty', 'accountant'].includes(user?.role || '')) {
        requests.push(axios.get('/api/students', { headers }));
      } else {
        requests.push(Promise.resolve({ data: [] }));
      }

      // Only fetch branches if authorized
      if (['superadmin', 'branch_admin'].includes(user?.role || '')) {
        requests.push(axios.get('/api/branches', { headers }));
      } else {
        requests.push(Promise.resolve({ data: [] }));
      }

      // Fetch calendars
      requests.push(axios.get('/api/academic-calendars', { headers }));

      if (user?.role === 'superadmin') {
        requests.push(axios.get('/api/settings/integrations', { headers }));
      } else {
        requests.push(Promise.resolve({ data: null }));
      }

      if (user?.role === 'student') {
        requests.push(axios.get('/api/enrollments', { headers }));
        requests.push(axios.get('/api/courses/available', { headers }));
      } else {
        requests.push(Promise.resolve({ data: [] }));
        requests.push(Promise.resolve({ data: [] }));
      }

      const responses = await Promise.all(requests);
      setStudents(responses[0].data);
      setBranches(responses[1].data);
      setCalendars(responses[2].data);
      if (responses[3]) setIntegrations(responses[3].data);
      if (user?.role === 'student') {
        setEnrollments(responses[4].data);
        setAvailableCourses(responses[5].data);
      }
    } catch (err) {
      console.error('Failed to fetch dashboard data', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token, user?.role]);

  const navigation = [
    { id: 'overview', icon: LayoutDashboard, label: 'Overview', roles: ['superadmin', 'branch_admin', 'faculty', 'accountant', 'student'] },
    { id: 'students', icon: Users, label: t('students'), roles: ['superadmin', 'branch_admin', 'faculty', 'accountant', 'registrar'] },
    { id: 'branches', icon: Building2, label: t('branches'), roles: ['superadmin', 'branch_admin'] },
    { id: 'academics', icon: BookOpen, label: t('academics'), roles: ['superadmin', 'branch_admin', 'faculty', 'student', 'registrar'] },
    { id: 'courses', icon: BookOpen, label: 'My Courses', roles: ['student'] },
    { id: 'calendar', icon: Bell, label: 'Calendar', roles: ['superadmin', 'branch_admin', 'registrar'] },
    { id: 'finance', icon: CreditCard, label: t('finance'), roles: ['superadmin', 'branch_admin', 'accountant', 'student', 'registrar'] },
    { id: 'registrar', icon: User, label: 'Registrar', roles: ['superadmin', 'registrar'] },
    { id: 'integrations', icon: Settings, label: 'Integrations', roles: ['superadmin'] },
  ].filter(item => item.roles.includes(user?.role || ''));

  const SidebarItem = ({ id, icon: Icon, label }: any) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all ${
        activeTab === id 
          ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' 
          : 'text-stone-500 hover:bg-stone-100'
      }`}
    >
      <Icon size={20} />
      <span className="font-semibold text-sm">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-stone-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-stone-200 p-6 flex flex-col">
        <div className="flex items-center gap-2 mb-10 px-2">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white">
            <LayoutDashboard size={18} />
          </div>
          <span className="text-lg font-bold tracking-tight text-stone-900">DREAMLAND</span>
        </div>

        <nav className="flex-1 space-y-2">
          {navigation.map(item => (
            <SidebarItem key={item.id} id={item.id} icon={item.icon} label={item.label} />
          ))}
        </nav>

        <div className="mt-auto pt-6 border-t border-stone-100">
          <div className="flex items-center gap-3 mb-6 px-2">
            <div className="w-10 h-10 bg-stone-100 rounded-full flex items-center justify-center text-stone-600 font-bold">
              {user?.full_name?.[0]}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-stone-900 truncate">{user?.full_name}</p>
              <p className="text-xs text-stone-500 capitalize">{user?.role.replace('_', ' ')}</p>
            </div>
          </div>
          <button 
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-50 rounded-2xl transition-all font-semibold text-sm"
          >
            <LogOut size={20} />
            {t('logout')}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-10">
        <header className="flex justify-between items-center mb-10">
          <div>
            <h1 className="text-3xl font-bold text-stone-900">
              {activeTab === 'overview' ? 'Welcome back, ' + user?.full_name : t(activeTab)}
            </h1>
            <p className="text-stone-500 mt-1">Here's what's happening at Dreamland College today.</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
              <input 
                type="text" 
                placeholder="Search anything..." 
                className="pl-12 pr-4 py-2.5 bg-white border border-stone-200 rounded-2xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none w-64 transition-all"
              />
            </div>
            <button className="p-2.5 bg-white border border-stone-200 rounded-2xl text-stone-600 hover:bg-stone-50 transition-all relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
            </button>
          </div>
        </header>

        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Total Students', value: students.length, icon: Users, color: 'bg-blue-500' },
                { label: 'Active Branches', value: branches.length, icon: Building2, color: 'bg-emerald-500' },
                { label: 'Programs', value: '12', icon: BookOpen, color: 'bg-purple-500' },
                { label: 'Revenue (ETB)', value: '1.2M', icon: CreditCard, color: 'bg-orange-500' }
              ].map((stat, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm"
                >
                  <div className={`w-12 h-12 ${stat.color} rounded-2xl flex items-center justify-center text-white mb-4 shadow-lg shadow-stone-100`}>
                    <stat.icon size={24} />
                  </div>
                  <p className="text-sm font-medium text-stone-500">{stat.label}</p>
                  <h3 className="text-2xl font-bold text-stone-900 mt-1">{stat.value}</h3>
                </motion.div>
              ))}
            </div>

            {/* Recent Students Table */}
            <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-stone-100 flex justify-between items-center">
                <h3 className="font-bold text-stone-900">Recent Students</h3>
                <button className="text-sm font-bold text-emerald-600 hover:text-emerald-700">View All</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-stone-50/50 text-stone-500 text-xs uppercase tracking-wider">
                      <th className="px-6 py-4 font-semibold">Student Name</th>
                      <th className="px-6 py-4 font-semibold">ID Code</th>
                      <th className="px-6 py-4 font-semibold">Branch</th>
                      <th className="px-6 py-4 font-semibold">Program</th>
                      <th className="px-6 py-4 font-semibold">Status</th>
                      <th className="px-6 py-4 font-semibold"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {students.slice(0, 5).map((student, i) => (
                      <tr key={i} className="hover:bg-stone-50 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-stone-100 rounded-full flex items-center justify-center text-stone-600 text-xs font-bold">
                              {student.full_name?.[0]}
                            </div>
                            <span className="text-sm font-semibold text-stone-900">{student.full_name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-stone-600 font-mono">{student.student_id_code || 'PENDING'}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{student.branch_name}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{student.program_name}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                            student.academic_status === 'good_standing' 
                              ? 'bg-emerald-50 text-emerald-600' 
                              : 'bg-red-50 text-red-600'
                          }`}>
                            {student.academic_status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button className="p-1.5 text-stone-400 hover:text-stone-600 transition-colors">
                            <MoreVertical size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {students.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-6 py-10 text-center text-stone-500 text-sm">
                          No students found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'courses' && (
          <div className="space-y-8">
            <div className="bg-white rounded-3xl border border-stone-200 shadow-sm p-6">
              <h2 className="font-bold text-stone-900 mb-6">My Enrollments</h2>
              <div className="divide-y divide-stone-100">
                {enrollments.map((e: any) => (
                  <div key={e.id} className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-stone-900">{e.course_name}</p>
                      <p className="text-xs text-stone-500">{e.course_code}</p>
                    </div>
                    <button 
                      onClick={async () => {
                        await axios.post('/api/enrollments/withdraw', { enrollment_id: e.id }, { headers: { Authorization: `Bearer ${token}` } });
                        fetchData();
                      }}
                      className="px-4 py-2 bg-red-50 text-red-600 rounded-xl text-sm font-semibold hover:bg-red-100"
                    >
                      Withdraw
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-stone-200 shadow-sm p-6">
              <h2 className="font-bold text-stone-900 mb-6">Available Courses</h2>
              <div className="divide-y divide-stone-100">
                {availableCourses.map((c: any) => (
                  <div key={c.id} className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-stone-900">{c.title}</p>
                      <p className="text-xs text-stone-500">{c.code}</p>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={async () => {
                          await axios.post('/api/enrollments', { course_offering_id: c.id, is_audit: false }, { headers: { Authorization: `Bearer ${token}` } });
                          fetchData();
                        }}
                        className="px-4 py-2 bg-emerald-50 text-emerald-600 rounded-xl text-sm font-semibold hover:bg-emerald-100"
                      >
                        Enroll
                      </button>
                      {c.is_auditable === 1 && (
                        <button 
                          onClick={async () => {
                            await axios.post('/api/enrollments', { course_offering_id: c.id, is_audit: true }, { headers: { Authorization: `Bearer ${token}` } });
                            fetchData();
                          }}
                          className="px-4 py-2 bg-stone-100 text-stone-600 rounded-xl text-sm font-semibold hover:bg-stone-200"
                        >
                          Audit
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'students' && (
          <div className="space-y-6">
             <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <input 
                      type="text" 
                      placeholder="Search students..." 
                      className="pl-12 pr-4 py-2.5 bg-white border border-stone-200 rounded-2xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none w-80 transition-all"
                    />
                  </div>
                  <button className="flex items-center gap-2 px-4 py-2.5 bg-white border border-stone-200 rounded-2xl text-sm font-semibold text-stone-600 hover:bg-stone-50 transition-all">
                    <Filter size={18} />
                    Filters
                  </button>
                </div>
                <button 
                  onClick={() => navigate('/register-student')}
                  className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-2xl text-sm font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                >
                  <Plus size={18} />
                  Add Student
                </button>
             </div>

             <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-stone-50/50 text-stone-500 text-xs uppercase tracking-wider">
                      <th className="px-6 py-4 font-semibold">Student</th>
                      <th className="px-6 py-4 font-semibold">ID</th>
                      <th className="px-6 py-4 font-semibold">Type</th>
                      <th className="px-6 py-4 font-semibold">Program</th>
                      <th className="px-6 py-4 font-semibold">Status</th>
                      <th className="px-6 py-4 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {students.map((student, i) => (
                      <tr key={i} className="hover:bg-stone-50 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center font-bold">
                              {student.full_name?.[0]}
                            </div>
                            <div>
                              <p className="text-sm font-bold text-stone-900">{student.full_name}</p>
                              <p className="text-xs text-stone-500">{student.username}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm font-mono text-stone-600">{student.student_id_code || 'N/A'}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{student.student_type}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{student.program_name}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                            student.academic_status === 'good_standing' 
                              ? 'bg-emerald-100 text-emerald-700' 
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {student.academic_status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button 
                            onClick={() => { setSelectedStudent(student); setIsEditModalOpen(true); }}
                            className="p-2 text-stone-400 hover:text-emerald-600 transition-colors"
                          >
                            <ChevronRight size={20} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
           </div>
        )}

        {activeTab === 'branches' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {branches.map((branch, i) => (
              <div key={i} className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm hover:border-emerald-200 transition-all group">
                <div className="w-14 h-14 bg-stone-50 rounded-2xl flex items-center justify-center text-stone-400 mb-6 group-hover:bg-emerald-50 group-hover:text-emerald-600 transition-all">
                  <Building2 size={28} />
                </div>
                <h3 className="text-xl font-bold text-stone-900 mb-2">{branch.name}</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-stone-500">
                    <MapPin size={16} />
                    {branch.location}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-stone-500">
                    <Phone size={16} />
                    {branch.contact}
                  </div>
                </div>
                <button className="w-full mt-8 py-3 bg-stone-50 text-stone-600 rounded-2xl text-sm font-bold hover:bg-emerald-600 hover:text-white transition-all">
                  Manage Branch
                </button>
              </div>
            ))}
            <button className="border-2 border-dashed border-stone-200 rounded-3xl p-8 flex flex-col items-center justify-center text-stone-400 hover:border-emerald-300 hover:text-emerald-500 transition-all group">
              <div className="w-12 h-12 rounded-full bg-stone-50 flex items-center justify-center mb-4 group-hover:bg-emerald-50 transition-all">
                <Plus size={24} />
              </div>
              <span className="font-bold">Add New Branch</span>
            </button>
          </div>
        )}

        {activeTab === 'integrations' && user?.role === 'superadmin' && (
          <div className="space-y-8">
            <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                  <ShieldCheck size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-stone-900">System Integrations</h3>
                  <p className="text-sm text-stone-500">Configure global API settings and mock mode toggles.</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="p-6 bg-stone-50 rounded-2xl border border-stone-100">
                  <h4 className="font-bold text-stone-900 mb-4 flex items-center gap-2">
                    <Bell size={18} className="text-emerald-600" />
                    AfroMessage (SMS)
                  </h4>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-stone-600">Mock Mode</span>
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${integrations?.afromessage_mock === 'true' ? 'bg-yellow-100 text-yellow-700' : 'bg-emerald-100 text-emerald-700'}`}>
                        {integrations?.afromessage_mock === 'true' ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>
                    <p className="text-xs text-stone-400 italic">API Key is managed via environment variables.</p>
                  </div>
                </div>

                <div className="p-6 bg-stone-50 rounded-2xl border border-stone-100">
                  <h4 className="font-bold text-stone-900 mb-4 flex items-center gap-2">
                    <CreditCard size={18} className="text-emerald-600" />
                    Chapa (Payments)
                  </h4>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-stone-600">Mock Mode</span>
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${integrations?.chapa_mock === 'true' ? 'bg-yellow-100 text-yellow-700' : 'bg-emerald-100 text-emerald-700'}`}>
                        {integrations?.chapa_mock === 'true' ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>
                    <p className="text-xs text-stone-400 italic">Public/Secret keys are managed via environment variables.</p>
                  </div>
                </div>

                <div className="p-6 bg-stone-50 rounded-2xl border border-stone-100 col-span-2">
                  <h4 className="font-bold text-stone-900 mb-4 flex items-center gap-2">
                    <Settings size={18} className="text-emerald-600" />
                    CBE Verifier Microservice
                  </h4>
                  <div className="flex items-center gap-4">
                    <input 
                      type="text" 
                      readOnly 
                      value={integrations?.cbe_verifier_url}
                      className="flex-1 px-4 py-2 bg-white border border-stone-200 rounded-xl text-sm font-mono text-stone-500"
                    />
                    <button className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-sm font-bold opacity-50 cursor-not-allowed">
                      Update URL
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        {activeTab === 'calendar' && (
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
              <h3 className="text-xl font-bold text-stone-900 mb-6">Academic Calendars</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-stone-50/50 text-stone-500 text-xs uppercase tracking-wider">
                      <th className="px-6 py-4 font-semibold">Semester</th>
                      <th className="px-6 py-4 font-semibold">Branch</th>
                      <th className="px-6 py-4 font-semibold">Start Date</th>
                      <th className="px-6 py-4 font-semibold">End Date</th>
                      <th className="px-6 py-4 font-semibold">Reg Period</th>
                      <th className="px-6 py-4 font-semibold">Exam Period</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {calendars.map((cal, i) => (
                      <tr key={i}>
                        <td className="px-6 py-4 text-sm font-semibold text-stone-900">{cal.semester_name}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{cal.branch_name}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{cal.start_date}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{cal.end_date}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{cal.reg_start_date} - {cal.reg_end_date}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{cal.exam_start_date} - {cal.exam_end_date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'registrar' && (
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
              <h3 className="text-xl font-bold text-stone-900 mb-6">Student Management (Registrar)</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-stone-50/50 text-stone-500 text-xs uppercase tracking-wider">
                      <th className="px-6 py-4 font-semibold">Name</th>
                      <th className="px-6 py-4 font-semibold">Student ID</th>
                      <th className="px-6 py-4 font-semibold">Branch</th>
                      <th className="px-6 py-4 font-semibold">Program</th>
                      <th className="px-6 py-4 font-semibold">Status</th>
                      <th className="px-6 py-4 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {students.map((student, i) => (
                      <tr key={i}>
                        <td className="px-6 py-4 text-sm font-semibold text-stone-900">{student.full_name}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{student.student_id_code}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{student.branch_name}</td>
                        <td className="px-6 py-4 text-sm text-stone-600">{student.program_name}</td>
                        <td className="px-6 py-4 text-sm">
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${student.academic_status === 'good_standing' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                            {student.academic_status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <button className="text-emerald-600 hover:underline font-semibold">View Profile</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {(activeTab === 'academics' || activeTab === 'finance') && (
          <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-stone-200 border-dashed">
            <div className="w-20 h-20 bg-stone-50 rounded-full flex items-center justify-center text-stone-300 mb-6">
              {activeTab === 'academics' ? <BookOpen size={40} /> : <CreditCard size={40} />}
            </div>
            <h3 className="text-xl font-bold text-stone-900 mb-2">{t(activeTab)} Module</h3>
            <p className="text-stone-500 max-w-xs text-center">This module is currently being initialized with your branch data. Please check back shortly.</p>
          </div>
        )}
        {isEditModalOpen && selectedStudent && (
          <EditStudentModal 
            student={selectedStudent} 
            onClose={() => setIsEditModalOpen(false)} 
            onUpdate={() => { fetchData(); setIsEditModalOpen(false); }} 
          />
        )}
      </main>
    </div>
  );
}
