import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import multer from "multer";
import fs from "fs";
import { CBEVerificationService } from './src/services/payment/cbeVerificationService';

const cbeVerifier = new CBEVerificationService();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
const upload = multer({ dest: "uploads/" });

const db = new Database("college.db");

// Initialize Database Schema
db.exec(`
  CREATE TABLE IF NOT EXISTS branches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    location TEXT,
    contact TEXT
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL, -- superadmin, branch_admin, faculty, accountant, student, parent
    branch_id INTEGER,
    full_name TEXT,
    email TEXT,
    FOREIGN KEY (branch_id) REFERENCES branches(id)
  );

  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE,
    student_id_code TEXT UNIQUE, -- e.g., AA-2024-0001
    branch_id INTEGER,
    program_id INTEGER,
    student_type TEXT, -- Regular, Extension, Weekend, Distance
    birth_year INTEGER,
    birth_place_region TEXT,
    birth_place_zone TEXT,
    birth_place_woreda TEXT,
    birth_place_kebele TEXT,
    contact_phone TEXT,
    emergency_contact_name TEXT,
    emergency_contact_phone TEXT,
    academic_status TEXT DEFAULT 'good_standing', -- good_standing, probation, suspended
    current_semester_id INTEGER,
    documents_json TEXT, -- JSON string of document URLs
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (branch_id) REFERENCES branches(id)
  );

  CREATE TABLE IF NOT EXISTS programs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    code TEXT UNIQUE,
    duration_years INTEGER,
    total_credits INTEGER
  );

  CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    credits INTEGER NOT NULL,
    prerequisites TEXT, -- Comma separated codes
    is_auditable INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS semesters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    branch_id INTEGER,
    academic_year TEXT, -- e.g., 2016 E.C.
    semester_name TEXT, -- e.g., Semester I
    start_date TEXT,
    end_date TEXT,
    is_active INTEGER DEFAULT 0,
    FOREIGN KEY (branch_id) REFERENCES branches(id)
  );

  CREATE TABLE IF NOT EXISTS enrollments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    course_id INTEGER,
    semester_id INTEGER,
    grade TEXT, -- A, B, C, D, F, NG
    points REAL,
    status TEXT DEFAULT 'enrolled', -- enrolled, dropped, withdrawn
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id),
    FOREIGN KEY (semester_id) REFERENCES semesters(id)
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    amount REAL,
    type TEXT, -- tuition, registration, etc.
    status TEXT DEFAULT 'pending', -- pending, paid, verified
    transaction_ref TEXT,
    payment_method TEXT, -- chapa, cbe_receipt
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id)
  );

  CREATE TABLE IF NOT EXISTS announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    branch_id INTEGER,
    title TEXT,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(id)
  );

  CREATE TABLE IF NOT EXISTS academic_calendars (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    branch_id INTEGER,
    semester_name TEXT,
    start_date TEXT,
    end_date TEXT,
    reg_start_date TEXT,
    reg_end_date TEXT,
    exam_start_date TEXT,
    exam_end_date TEXT,
    FOREIGN KEY (branch_id) REFERENCES branches(id)
  );

  // Add new columns to students if they don't exist
  try {
    db.prepare("ALTER TABLE students ADD COLUMN birth_location TEXT").run();
  } catch (e) {
    // Column likely already exists
  }

  // Add grade columns to enrollments if they don't exist
  try {
    db.prepare("ALTER TABLE enrollments ADD COLUMN assignment_grade REAL").run();
    db.prepare("ALTER TABLE enrollments ADD COLUMN midterm_grade REAL").run();
    db.prepare("ALTER TABLE enrollments ADD COLUMN final_grade REAL").run();
    db.prepare("ALTER TABLE enrollments ADD COLUMN is_audit INTEGER DEFAULT 0").run();
    db.prepare("ALTER TABLE enrollments ADD COLUMN resolution_deadline TEXT").run();
  } catch (e) {
    // Columns likely already exist
  }

  // Create new tables
  db.prepare("CREATE TABLE IF NOT EXISTS registration_periods (" +
      "id INTEGER PRIMARY KEY AUTOINCREMENT," +
      "branch_id INTEGER," +
      "semester_id INTEGER," +
      "start_date TEXT," +
      "end_date TEXT," +
      "is_open INTEGER DEFAULT 1," +
      "FOREIGN KEY (branch_id) REFERENCES branches(id)," +
      "FOREIGN KEY (semester_id) REFERENCES semesters(id)" +
    ")").run();

  db.prepare("CREATE TABLE IF NOT EXISTS course_offerings (" +
      "id INTEGER PRIMARY KEY AUTOINCREMENT," +
      "course_id INTEGER," +
      "semester_id INTEGER," +
      "capacity INTEGER DEFAULT 30," +
      "FOREIGN KEY (course_id) REFERENCES courses(id)," +
      "FOREIGN KEY (semester_id) REFERENCES semesters(id)" +
    ")").run();

  db.prepare("CREATE TABLE IF NOT EXISTS course_waitlist (" +
      "id INTEGER PRIMARY KEY AUTOINCREMENT," +
      "course_offering_id INTEGER," +
      "student_id INTEGER," +
      "position INTEGER," +
      "created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
      "FOREIGN KEY (course_offering_id) REFERENCES course_offerings(id)," +
      "FOREIGN KEY (student_id) REFERENCES students(id)" +
    ")").run();
`);

// Seed initial data if empty
const branchCount = db.prepare("SELECT COUNT(*) as count FROM branches").get() as { count: number };
if (branchCount.count === 0) {
  db.prepare("INSERT INTO branches (name, location, contact) VALUES (?, ?, ?)").run("Addis Ababa Main", "Addis Ababa, 4 Kilo", "+251111223344");
  db.prepare("INSERT INTO branches (name, location, contact) VALUES (?, ?, ?)").run("Adama Branch", "Adama, City Center", "+251221112233");
  
  db.prepare("INSERT INTO users (username, password, role, full_name) VALUES (?, ?, ?, ?)").run("admin", "admin123", "superadmin", "System Administrator");
  
  db.prepare("INSERT INTO programs (name, code, duration_years, total_credits) VALUES (?, ?, ?, ?)").run("Computer Science", "CS", 4, 147);
  db.prepare("INSERT INTO programs (name, code, duration_years, total_credits) VALUES (?, ?, ?, ?)").run("Accounting & Finance", "ACC", 3, 110);

  db.prepare("INSERT INTO courses (code, title, credits) VALUES (?, ?, ?)").run("CS101", "Introduction to Programming", 3);
  db.prepare("INSERT INTO courses (code, title, credits) VALUES (?, ?, ?)").run("CS102", "Data Structures", 4);
}

import cron from 'node-cron';
import { AfroMessageService } from './src/services/messaging/afroMessageService';

// Initialize AfroMessageService
const afroMessage = new AfroMessageService({
  apiKey: process.env.AFROMESSAGE_API_KEY,
  senderId: process.env.AFROMESSAGE_SENDER_ID,
  mockMode: process.env.AFROMESSAGE_MOCK_MODE !== 'false'
});

// Daily Cron Job at 08:00
cron.schedule('0 8 * * *', async () => {
  const today = new Date().toISOString().split('T')[0];

  // 1. Registration Day Reminders
  const regPeriods = db.prepare("SELECT * FROM registration_periods WHERE end_date = ? AND is_open = 1").all(today) as any[];
  for (const period of regPeriods) {
    const students = db.prepare("SELECT s.phone, s.full_name FROM students s JOIN enrollments e ON s.id = e.student_id WHERE e.semester_id = ?").all(period.semester_id) as any[];
    for (const student of students) {
      await afroMessage.sendSMS(student.phone, `Dear ${student.full_name}, today is the last day for registration. Please complete your payment.`);
    }
  }

  // 2. End of Course Reminders
  const coursesEnding = db.prepare("SELECT c.title, e.student_id FROM enrollments e JOIN courses c ON e.course_id = c.id JOIN academic_calendars ac ON e.semester_id = ac.id WHERE ac.end_date = ?").all(today) as any[];
  for (const record of coursesEnding) {
    const student = db.prepare("SELECT phone, full_name FROM students WHERE id = ?").get(record.student_id) as any;
    if (student) {
      await afroMessage.sendSMS(student.phone, `Dear ${student.full_name}, your course ${record.title} is ending today. Please ensure all payments are settled.`);
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  const JWT_SECRET = process.env.JWT_SECRET || "dreamland-secret-key";

  // Public API Routes
  app.get("/api/public/branches", (req, res) => {
    const branches = db.prepare("SELECT * FROM branches").all();
    res.json(branches);
  });

  app.get("/api/public/programs", (req, res) => {
    const programs = db.prepare("SELECT * FROM programs").all();
    res.json(programs);
  });

  app.post("/api/public/upload", upload.single("file"), (req, res) => {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    res.json({ url: `/uploads/${req.file.filename}` });
  });

  app.post("/api/public/register-student", (req, res) => {
    const { 
      full_name, birth_year, region, zone, woreda, kebele, 
      phone, email, emergency_name, emergency_phone,
      program_id, student_type, branch_id, 
      diploma_url, transcript_url, id_card_url
    } = req.body;

    // Generate Student ID: BRANCH-YEAR-SEQUENCE
    const branch = db.prepare("SELECT name FROM branches WHERE id = ?").get(branch_id) as any;
    const branchCode = branch.name.substring(0, 2).toUpperCase();
    const year = new Date().getFullYear();
    const count = db.prepare("SELECT COUNT(*) as count FROM students").get() as { count: number };
    const student_id_code = `${branchCode}-${year}-${String(count.count + 1).padStart(4, '0')}`;

    // Create user first
    const userResult = db.prepare("INSERT INTO users (username, password, role, full_name, email) VALUES (?, ?, ?, ?, ?)").run(
      email, "password123", "student", full_name, email
    );

    // Create student
    const studentResult = db.prepare(`
      INSERT INTO students (
        user_id, student_id_code, branch_id, program_id, student_type, 
        birth_year, birth_place_region, birth_place_zone, birth_place_woreda, birth_place_kebele,
        contact_phone, emergency_contact_name, emergency_contact_phone, documents_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      userResult.lastInsertRowid, student_id_code, branch_id, program_id, student_type,
      birth_year, region, zone, woreda, kebele,
      phone, emergency_name, emergency_phone, JSON.stringify({ diploma_url, transcript_url, id_card_url })
    );

    res.json({ id: studentResult.lastInsertRowid, student_id_code });
  });

  // Academic Status Update Logic
  const updateAcademicStatus = (student_id: number) => {
    const enrollments = db.prepare("SELECT * FROM enrollments WHERE student_id = ? AND grade IS NOT NULL AND is_audit = 0").all(student_id) as any[];
    if (enrollments.length === 0) return;

    const failedCourses = enrollments.filter(e => e.grade === 'F').length;
    const totalPoints = enrollments.reduce((sum, e) => sum + (e.points || 0), 0);
    const gpa = totalPoints / enrollments.length;

    let status = 'good_standing';
    if (failedCourses > 2 || gpa < 1.5) {
      status = 'probation';
    }
    // Add logic for suspension if needed

    db.prepare("UPDATE students SET academic_status = ? WHERE id = ?").run(status, student_id);
  };

  // Check for expired Incomplete grades
  const checkExpiredIncompleteGrades = () => {
    const now = new Date().toISOString();
    const expired = db.prepare("SELECT * FROM enrollments WHERE grade = 'I' AND resolution_deadline < ?").all(now) as any[];
    for (const e of expired) {
      db.prepare("UPDATE enrollments SET grade = 'F' WHERE id = ?").run(e.id);
      updateAcademicStatus(e.student_id);
    }
  };
  setInterval(checkExpiredIncompleteGrades, 24 * 60 * 60 * 1000); // Check daily

  // Registration Eligibility Check
  const isEligibleForRegistration = (student_id: number) => {
    const student = db.prepare("SELECT academic_status FROM students WHERE id = ?").get(student_id) as any;
    return student.academic_status !== 'probation' && student.academic_status !== 'suspended';
  };

  // Auth Middleware
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    try {
      req.user = jwt.verify(token, JWT_SECRET);
      next();
    } catch (e) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  const authorize = (roles: string[]) => {
    return (req: any, res: any, next: any) => {
      if (!req.user) return res.status(401).json({ error: "Unauthorized" });
      if (!roles.includes(req.user.role)) {
        return res.status(403).json({ error: "Forbidden: Insufficient permissions" });
      }
      next();
    };
  };

  // API Routes
  app.post("/api/auth/login", (req, res) => {
    const { username, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE username = ? AND password = ?").get(username, password) as any;
    if (user) {
      const token = jwt.sign({ id: user.id, username: user.username, role: user.role, branch_id: user.branch_id }, JWT_SECRET);
      res.json({ token, user: { id: user.id, username: user.username, role: user.role, full_name: user.full_name, branch_id: user.branch_id } });
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  });

  // Branch Management (Superadmin only)
  app.get("/api/branches", authenticate, authorize(['superadmin', 'branch_admin']), (req, res) => {
    const { role, branch_id } = (req as any).user;
    if (role === 'superadmin') {
      const branches = db.prepare("SELECT * FROM branches").all();
      return res.json(branches);
    }
    const branch = db.prepare("SELECT * FROM branches WHERE id = ?").get(branch_id);
    res.json([branch]);
  });

  app.post("/api/branches", authenticate, authorize(['superadmin']), (req, res) => {
    const { name, location, contact } = req.body;
    const result = db.prepare("INSERT INTO branches (name, location, contact) VALUES (?, ?, ?)").run(name, location, contact);
    res.json({ id: result.lastInsertRowid, name, location, contact });
  });

  // Student Management
  app.get("/api/students", authenticate, authorize(['superadmin', 'branch_admin', 'faculty', 'accountant', 'registrar']), (req, res) => {
    const { branch_id, role } = (req as any).user;
    let students;
    if (role === 'superadmin') {
      students = db.prepare(`
        SELECT s.*, u.full_name, u.username, b.name as branch_name, p.name as program_name 
        FROM students s 
        JOIN users u ON s.user_id = u.id 
        JOIN branches b ON s.branch_id = b.id
        LEFT JOIN programs p ON s.program_id = p.id
      `).all();
    } else {
      students = db.prepare(`
        SELECT s.*, u.full_name, u.username, b.name as branch_name, p.name as program_name 
        FROM students s 
        JOIN users u ON s.user_id = u.id 
        JOIN branches b ON s.branch_id = b.id
        LEFT JOIN programs p ON s.program_id = p.id
        WHERE s.branch_id = ?
      `).all(branch_id);
    }
    res.json(students);
  });

  app.post("/api/students", authenticate, authorize(['superadmin', 'branch_admin']), (req, res) => {
    const { 
      full_name, birth_year, region, zone, woreda, kebele, 
      phone, email, emergency_name, emergency_phone,
      program_id, student_type, branch_id, status
    } = req.body;

    // Generate Student ID: BRANCH-YEAR-SEQUENCE
    const branch = db.prepare("SELECT name FROM branches WHERE id = ?").get(branch_id) as any;
    const branchCode = branch.name.substring(0, 2).toUpperCase();
    const year = new Date().getFullYear();
    const count = db.prepare("SELECT COUNT(*) as count FROM students").get() as { count: number };
    const student_id_code = `${branchCode}-${year}-${String(count.count + 1).padStart(4, '0')}`;

    // Create user first
    const userResult = db.prepare("INSERT INTO users (username, password, role, full_name, email) VALUES (?, ?, ?, ?, ?)").run(
      email, "password123", "student", full_name, email
    );

    // Create student
    const studentResult = db.prepare(`
      INSERT INTO students (
        user_id, student_id_code, branch_id, program_id, student_type, 
        birth_year, birth_place_region, birth_place_zone, birth_place_woreda, birth_place_kebele,
        contact_phone, emergency_contact_name, emergency_contact_phone, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      userResult.lastInsertRowid, student_id_code, branch_id, program_id, student_type,
      birth_year, region, zone, woreda, kebele,
      phone, emergency_name, emergency_phone, status
    );

    res.json({ id: studentResult.lastInsertRowid, student_id_code });
  });

  // Student Enrollment
  app.post("/api/enrollments", authenticate, authorize(['student']), (req, res) => {
    const { course_offering_id, is_audit } = req.body;
    const student_id = (req as any).user.id;

    // Check registration period
    const period = db.prepare("SELECT * FROM registration_periods WHERE is_open = 1").get() as any;
    if (!period) return res.status(400).json({ error: "Registration is closed" });

    // Check capacity
    const offering = db.prepare("SELECT * FROM course_offerings WHERE id = ?").get(course_offering_id) as any;
    const course = db.prepare("SELECT * FROM courses WHERE id = ?").get(offering.course_id) as any;
    
    if (is_audit && !course.is_auditable) {
      return res.status(400).json({ error: "Course is not auditable" });
    }

    const enrolledCount = db.prepare("SELECT COUNT(*) as count FROM enrollments WHERE course_id = ? AND semester_id = ?").get(offering.course_id, offering.semester_id) as { count: number };
    
    if (enrolledCount.count >= offering.capacity) {
      // Add to waitlist
      const waitlistCount = db.prepare("SELECT COUNT(*) as count FROM course_waitlist WHERE course_offering_id = ?").get(course_offering_id) as { count: number };
      db.prepare("INSERT INTO course_waitlist (course_offering_id, student_id, position) VALUES (?, ?, ?)").run(course_offering_id, student_id, waitlistCount.count + 1);
      return res.json({ message: "Course full, added to waitlist" });
    }

    // Check prerequisites (only if not auditing)
    if (!is_audit && course.prerequisites) {
      const prereqs = course.prerequisites.split(',');
      for (const prereq of prereqs) {
        const completed = db.prepare("SELECT grade FROM enrollments e JOIN courses c ON e.course_id = c.id WHERE e.student_id = ? AND c.code = ? AND e.grade != 'F'").get(student_id, prereq.trim());
        if (!completed) return res.status(400).json({ error: `Prerequisite ${prereq} not met` });
      }
    }

    db.prepare("INSERT INTO enrollments (student_id, course_id, semester_id, is_audit) VALUES (?, ?, ?, ?)").run(student_id, offering.course_id, offering.semester_id, is_audit ? 1 : 0);
    res.json({ message: "Enrolled successfully" });
  });

  app.get("/api/enrollments", authenticate, authorize(['student']), (req, res) => {
    const student_id = (req as any).user.id;
    const enrollments = db.prepare(`
      SELECT e.*, c.name as course_name, c.code as course_code 
      FROM enrollments e 
      JOIN courses c ON e.course_id = c.id 
      WHERE e.student_id = ?
    `).all(student_id);
    res.json(enrollments);
  });

  // Student Withdrawal
  app.post("/api/enrollments/withdraw", authenticate, authorize(['student']), (req, res) => {
    const { enrollment_id } = req.body;
    const student_id = (req as any).user.id;
    
    const enrollment = db.prepare("SELECT * FROM enrollments WHERE id = ? AND student_id = ?").get(enrollment_id, student_id) as any;
    if (!enrollment) return res.status(404).json({ error: "Enrollment not found" });
    
    db.prepare("UPDATE enrollments SET status = 'withdrawn' WHERE id = ?").run(enrollment_id);
    
    // Trigger waitlist promotion
    const nextWaitlist = db.prepare("SELECT * FROM course_waitlist WHERE course_offering_id = ? ORDER BY position ASC LIMIT 1").get(enrollment.course_id) as any;
    if (nextWaitlist) {
      db.prepare("INSERT INTO enrollments (student_id, course_id, semester_id) VALUES (?, ?, ?)").run(nextWaitlist.student_id, enrollment.course_id, enrollment.semester_id);
      db.prepare("DELETE FROM course_waitlist WHERE id = ?").run(nextWaitlist.id);
    }
    
    res.json({ message: "Withdrawn successfully" });
  });

  // Faculty Grade Entry
  app.post("/api/enrollments/grades", authenticate, authorize(['faculty']), (req, res) => {
    const { enrollment_id, assignment_grade, midterm_grade, final_grade } = req.body;
    const points = (assignment_grade * 0.2) + (midterm_grade * 0.3) + (final_grade * 0.5);
    let grade = 'F';
    if (points >= 90) grade = 'A';
    else if (points >= 80) grade = 'B';
    else if (points >= 70) grade = 'C';
    else if (points >= 60) grade = 'D';
    
    db.prepare("UPDATE enrollments SET assignment_grade = ?, midterm_grade = ?, final_grade = ?, points = ?, grade = ? WHERE id = ?").run(assignment_grade, midterm_grade, final_grade, points, grade, enrollment_id);
    res.json({ message: "Grades updated successfully" });
  });

  // Registration Periods Management
  app.post("/api/registration-periods", authenticate, authorize(['superadmin']), (req, res) => {
    const { branch_id, semester_id, start_date, end_date } = req.body;
    db.prepare("INSERT INTO registration_periods (branch_id, semester_id, start_date, end_date) VALUES (?, ?, ?, ?)").run(branch_id, semester_id, start_date, end_date);
    res.json({ message: "Registration period defined" });
  });


  // Available Courses
  app.get("/api/courses/available", authenticate, authorize(['student']), (req, res) => {
    const courses = db.prepare("SELECT co.*, c.title, c.code, c.is_auditable FROM course_offerings co JOIN courses c ON co.course_id = c.id WHERE co.semester_id = (SELECT id FROM semesters WHERE is_active = 1)").all();
    res.json(courses);
  });

  // Payment Verification
  app.post("/api/payments/verify", authenticate, authorize(['student']), async (req, res) => {
  const { reference, last8Digits, student_id } = req.body;
  
  const result = await cbeVerifier.verify(reference, last8Digits);
  
  if (result.success) {
    // Mark fee paid in database
    db.prepare("INSERT INTO payments (student_id, amount, status, transaction_ref, payment_method) VALUES (?, ?, ?, ?, ?)").run(student_id, result.amount, 'verified', reference, 'cbe_receipt');
    
    // Send confirmation SMS
    const student = db.prepare("SELECT phone, full_name FROM students WHERE id = ?").get(student_id) as any;
    if (student) {
      await afroMessage.sendSMS(student.phone, `Dear ${student.full_name}, your payment of ${result.amount} ETB has been verified successfully.`);
    }
    
    res.json({ message: "Payment verified successfully", amount: result.amount });
  } else {
    res.status(400).json({ error: result.error });
  }
});

  // Integration Settings (Superadmin only)
  app.get("/api/settings/integrations", authenticate, authorize(['superadmin']), (req, res) => {
    res.json({
      afromessage_mock: process.env.AFROMESSAGE_MOCK_MODE || 'true',
      chapa_mock: process.env.CHAPA_MOCK_MODE || 'true',
      cbe_verifier_url: process.env.CBE_VERIFIER_URL || 'http://localhost:5001'
    });
  });

  // File Upload
  app.post("/api/upload", authenticate, upload.single("file"), (req, res) => {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    res.json({ url: `/uploads/${req.file.filename}` });
  });
  app.use("/uploads", express.static(uploadDir));

  app.get("/api/programs", authenticate, (req, res) => {
    const programs = db.prepare("SELECT * FROM programs").all();
    res.json(programs);
  });

  app.get("/api/announcements", authenticate, (req, res) => {
    const announcements = db.prepare("SELECT * FROM announcements ORDER BY created_at DESC LIMIT 5").all();
    res.json(announcements);
  });

  // Mock AfroMessage
  app.post("/api/sms/send", authenticate, authorize(['superadmin', 'branch_admin', 'accountant']), (req, res) => {
    const { to, message } = req.body;
    const isMock = process.env.AFROMESSAGE_MOCK_MODE !== 'false';
    
    if (isMock) {
      console.log(`[MOCK SMS] To: ${to}, Message: ${message}`);
      return res.json({ success: true, message: "SMS sent (Mock Mode)" });
    }
    
    // Real integration logic would go here using process.env.AFROMESSAGE_API_KEY
    res.json({ success: true, message: "SMS sent" });
  });

  // Mock Chapa Payment
  app.post("/api/payments/initialize", authenticate, authorize(['superadmin', 'branch_admin', 'student', 'accountant']), (req, res) => {
    const { amount, email, first_name, last_name } = req.body;
    const isMock = process.env.CHAPA_MOCK_MODE !== 'false';
    const tx_ref = `TX-${Date.now()}`;

    if (isMock) {
      return res.json({
        status: "success",
        message: "Hosted payment link generated (Mock Mode)",
        data: {
          checkout_url: `https://checkout.chapa.co/checkout/payment/${tx_ref}`
        }
      });
    }

    // Real integration logic would go here using process.env.CHAPA_SECRET_KEY
    res.json({
      status: "success",
      data: { checkout_url: `https://checkout.chapa.co/checkout/payment/${tx_ref}` }
    });
  });

  // Mock CBE Receipt Verification
  app.post("/api/payments/verify-cbe", authenticate, (req, res) => {
    const { reference, amount } = req.body;
    console.log(`[MOCK CBE VERIFY] Ref: ${reference}, Amount: ${amount}`);
    res.json({
      verified: true,
      extracted_data: {
        reference,
        amount,
        date: new Date().toISOString()
      }
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
